var app = angular.module('zongotechWpApp.controllers', [])


app.controller('NavCtrl', function ($scope, $ionicSideMenuDelegate,wpzSettings) {
    $scope.showMenu = function () {
        $ionicSideMenuDelegate.toggleLeft();
    };
    $scope.showRightMenu = function () {
        $ionicSideMenuDelegate.toggleRight();
    };
})

app.controller('CatListCtrl', function ($http, $scope, $sce, $ionicScrollDelegate,wpzSettings) {
    $scope.categories = [];
    $http.get(wpzSettings.siteApiUrl + "get_category_index/").then(function (returnedData) {
        $scope.categories = returnedData.data.categories;
        $scope.categories.forEach(function (element, index, array) {
            element.title = $sce.trustAsHtml(element.title);
        })
        console.log(returnedData);

    }, function (err) {
        console.log(err);
    })

    if (window.AdMob) AdMob.showInterstitial();
  
})

app.controller('HomeTabCtrl', function ($http, $scope, $sce, $ionicScrollDelegate,wpzSettings) {
    $scope.offset = 0;
    $scope.count_total = 1;
    $scope.moreItems = false;
    $scope.sliderCategory = wpzSettings.featureCategory;//2058;
    $scope.featureTitle = wpzSettings.featureTitle;//2058;
$scope.homeTitle=wpzSettings.homeTitle;

    $scope.doRefresh = function () {
        $scope.recent_posts = [];

        $http.get(wpzSettings.siteApiUrl + "get_category_posts/?id="+ $scope.sliderCategory+"&count=1").then(function (data) {
                     
            //feature post
            $scope.features_posts = data.data.posts[0];
            $scope.features_postTitle = $scope.features_posts.title;
            $scope.features_postExcert = $scope.features_posts.excerpt;
            $scope.features_postImage = $scope.features_posts.thumbnail_images.full.url;
            $scope.features_postId = $scope.features_posts.id;
            // Stop the ion-refresher from spinning
           // $scope.$broadcast('scroll.refreshComplete');

        }, function (err) { })
        //end feature slider post

        $http.get(wpzSettings.siteApiUrl + "get_posts/?count=10").then(function (data) {
            //console.log(data); category_Not_in=9
           
            $scope.recent_posts = data.data.posts;
            //do not delete
            //$scope.recent_posts.forEach(function (element, index, array) {

            //    element.excerpt = element.excerpt.substr(0, 100) + "... Read More";
            //    element.excerpt = $sce.trustAsHtml(element.excerpt);
                                    
            //})
            //feature post
            //$scope.features_posts = $scope.recent_posts[0];
            //$scope.features_postTitle = $scope.features_posts.title;
            //$scope.features_postExcert = $scope.features_posts.excerpt;
            //$scope.features_postImage = $scope.features_posts.thumbnail_images.full.url;
            //$scope.features_postId = $scope.features_posts.id;
            ////remove item 0
            //$scope.recent_posts.splice(0,1)
            // Stop the ion-refresher from spinning
            $scope.$broadcast('scroll.refreshComplete');

        }, function (err) { })
    }
    //here

    $scope.recent_posts = [];
    $http.get(wpzSettings.siteApiUrl + "get_posts/?count=10").then(function (data) {
        console.log(data);

        $scope.recent_posts = data.data.posts
        $scope.recent_posts.forEach(function (element, index, array) {
            element.excerpt = element.excerpt.substr(0, 100) + "... Read More";
            element.excerpt = $sce.trustAsHtml(element.excerpt);
//remove feature image
            //if(element.id=$scope.features_postId){
            //    $scope.recent_posts.splice(index,1)
          //  }
        })

    },
    function (err) {
    })

    $scope.canLoadMore = function () {
        return $scope.count_total >0;
    }
    $scope.myCount = 0;
    $scope.loadMore = function () {
        console.log($scope.myCount++);
        $http.get(wpzSettings.siteApiUrl + "get_posts/?offset=" + $scope.offset).then(function (data) {
            var newPosts = data.data.posts;
            $scope.count_total = data.data.count_total;

            newPosts.forEach(function (element, index, array) {
                element.excerpt = element.excerpt.substr(0, 70) + "... Read More";
                element.excerpt = $sce.trustAsHtml(element.excerpt);
            })
            $scope.recent_posts.push.apply($scope.recent_posts, newPosts);
            $scope.$broadcast('scroll.infiniteScrollComplete');
            $scope.offset += 10;
        })

    }
    $scope.toggleFavorite = function (post) {
        post.isFavorite = !post.isFavorite;
        if (post.isFavorite) {
            if($scope.Favorites==undefined) $scope.Favorites=[];
            $scope.Favorites.push(post.id);
        }
        else {
            $scope.Favorites.forEach(function (e, i, a) {
                if (e == post.id) {
                    $scope.Favorites.splice(i, 1);
                    console.log("Spliced index " + i)
                }
            })
        }
    }
    $scope.searchTextChanged = function () {
        $ionicScrollDelegate.$getByHandle('mainScroll').scrollTop(true);
    }


    $scope.doRefresh();
})

app.controller('CatCtrl', function ($http, $scope, $sce, $stateParams, $localStorage,wpzSettings) {
    $scope.Favorites = $localStorage.Favorites;
    $scope.category_posts = [];
    $scope.offset = 0;
    $scope.count_total = 1;

    $scope.doRefresh = function () {
        $http.get(wpzSettings.siteApiUrl + 'get_category_posts/?id=' + $stateParams.catId).then(function (returnedData) {
            $scope.category_posts = returnedData.data.posts;
            $scope.category_posts.forEach(function (element, index, array) {
                element.excerpt = element.excerpt.substr(0, 125);
                element.excerpt = element.excerpt + '[...]';
                element.excerpt = $sce.trustAsHtml(element.excerpt);
                if ($scope.Favorites.indexOf(element.id) != -1)
                    element.isFavorite = true;
                else
                    element.isFavorite = false;

            })
            $scope.category_title = returnedData.data.category.title;
            $scope.$broadcast('scroll.refreshComplete');
        },
   function (err) {
   }
   )

    }
    $scope.doRefresh();
    $scope.canLoadMore = function () {
        return $scope.count_total>0;
    }
    $scope.myCount = 0;

    $scope.loadMore = function () {
        console.log($scope.myCount++);
        $http.get(wpzSettings.siteApiUrl + 'get_category_posts/?id=' + $stateParams.catId + '&offset=' + $scope.offset).then(function (returnedData) {

            var newCategoryPosts = returnedData.data.posts;
            newCategoryPosts.forEach(function (element, index, array) {
                element.excerpt = element.excerpt.substr(0, 125);
                element.excerpt = element.excerpt + '[...]';
                element.excerpt = $sce.trustAsHtml(element.excerpt);
                if ($scope.Favorites.indexOf(element.id) != -1)
                    element.isFavorite = true;
                else
                    element.isFavorite = false;

            })

            $scope.category_posts.push.apply($scope.category_posts, newCategoryPosts);
            $scope.$broadcast('scroll.infiniteScrollComplete');
            $scope.offset += 10;
        })
    }//end load more
});
app.controller('PostCtrl', function ($http, $scope, $sce, $stateParams, $localStorage,wpzSettings) {

    $scope.Favorites = $localStorage.Favorites;
    if (!$scope.Favorites)
        $scope.Favorites = [];

    $http.get(wpzSettings.siteApiUrl + 'get_post/?id=' + $stateParams.postId)
    .then(function (data) {
        $scope.post_post = data.data.post;
        $scope.post_title = data.data.post.title;
        $scope.post_category = data.data.post.categories[0].title ? data.data.post.categories.title : 'Pas de rubrique';
        $scope.post_content = $sce.trustAsHtml(data.data.post.content);
        $scope.post_date = data.data.post.date;
        $scope.post_authorName = data.data.post.author.first_name + "  " + data.data.post.author.last_name;
        if ($scope.post_authorName.trim() == '')
            $scope.post_authorName = data.data.post.author.nickname;

        $scope.post_authorImage = data.data.post.author.url == '' ? 'http://burkina24.com/img/b24icon.jpg' :data.data.post.author.url;// 'http://ionicframework.com/img/docs/mcfly.jpg';

        $scope.post_image = data.data.post.thumbnail_images == undefined ? 'http://burkina24.com/img/b24temp.jpg' : data.data.post.thumbnail_images.full.url;
        $scope.post_commentCount = data.data.post.comment_count;
     //   $scope.post_views = data.data.post.custom_fields.post_views_count== undefined ? 77: data.data.post.custom_fields.post_views_count[0];
        $scope.post_url = data.data.post.url;
       

        if ($scope.Favorites.indexOf(data.data.post.id) != -1)
            $scope.post_IsFavorite = true;
        else
            $scope.post_IsFavorite = false;

    },

    function (err) {

    })

    $scope.share = function () {
        window.plugins.socialsharing.share($scope.post_title, $scope.post_title, $scope.post_image, $scope.post_url);
    }


    $scope.toggleFavorite = function (post) {
        post.isFavorite = !post.isFavorite;

        if (post.isFavorite) {
            $scope.Favorites.push(post.id);
        }
        else {
            $scope.Favorites.forEach(function (e, i, a) {
                if (e == post.id) {
                    $scope.Favorites.splice(i, 1);
                    console.log("Spliced index " + i)
                }
            })
        }
        $localStorage.Favorites = $scope.Favorites;
        $scope.post_IsFavorite = post.isFavorite;
    }
});

app.controller('FavCtrl', function ($http, $scope, $sce, $localStorage,wpzSettings) {
    $scope.doRefresh = function () {

        $scope.Favorites = $localStorage.Favorites;

         if (!$scope.Favorites) $scope.Favorites = [];


        $scope.favorite_posts = [];

        $scope.Favorites.forEach(function (element, index, array) {
            $http.get(wpzSettings.siteApiUrl + 'get_post/?id=' + element)
                .success(function (data) {
                    $scope.favorite_posts.push(data.post);
                    if ($scope.favorite_posts.length == $scope.Favorites.length) {
                        $scope.favorite_posts.forEach(function (post, position, list) {
                            post.excerpt = post.excerpt.substr(0, 125) + "[...]";
                            post.excerpt = $sce.trustAsHtml(post.excerpt);
                            if ($scope.Favorites.indexOf(post.id) != -1) {
                                post.isFavorite = true;
                            }
                            else {
                                post.isFavorite = false;
                            }

                        })
                    }//end iff
                })
            .finally(function () {
                //refresher from spinning
                $scope.$broadcast('scroll.refreshComplete');
            })
        })
        //admob show home      


    }
     if (window.AdMob) AdMob.showInterstitial();
    $scope.doRefresh();

    

    $scope.toggleFavorite = function (post) {
        post.isFavorite = !post.isFavorite;
        if (post.isFavorite) {
            $scope.Favorites.push(post.id);
        }
        else {
            $scope.Favorites.forEach(function (e, i, a) {
                if (e == post.id) {
                    $scope.Favorites.splice(i, 1);
                    console.log("Spliced index " + i)
                }
            })
        }
        $localStorage.Favorites = $scope.Favorites;
    }
});


app.controller('TwitterCtrl', function ($scope, $ionicPlatform, TwitterService) {
    // 1
    $scope.correctTimestring = function(string) {
        return new Date(Date.parse(string));
    };
    // 2
    $scope.showHomeTimeline = function() {
        $scope.home_timeline = TwitterService.getHomeTimeline();
    };
    // 3
    $scope.doRefresh = function() {
        $scope.showHomeTimeline();
        $scope.$broadcast('scroll.refreshComplete');
    };
    // 4
    $ionicPlatform.ready(function() {
        if (TwitterService.isAuthenticated()) {
            $scope.showHomeTimeline();
        } else {
            TwitterService.initialize().then(function(result) {
                if(result === true) {
                    $scope.showHomeTimeline();
                }
            });
        }
    });
  
});



app.controller('MyTwitterCtrl', function ($scope, $http,wpzSettings) {
    //alert("twitter");
    // 1
   var twitter_api_url = "https://api.twitter.com/1.1/statuses/user_timeline.json"
        , config = {
            params: {
                screen_name: wpzSettings.widget_data_username
                , callback: "JSON_CALLBACK"
                , include_rts: true
                , count: wpzSettings.widget_data_count
                , clientsource: "TWITTERINC_WIDGET"
                , "1340767850386": "cachebus"
            }
        };

    $http.jsonp( twitter_api_url, config).success(
        function( data, status, headers, config )
        {
            $scope.username_html = '@' + wpzSettings.widget_data_username;
            $scope.username_href = wpzSettings.widget_data_username;
            $scope.tweets = data;
        }
    );
  
});


app.controller('MyFacebookCtrl', function ($scope, $http,wpzSettings) {
    //alert("twitter");
    // 1
   
  
});