(function () {
    var app = angular.module('zongotechWpApp', ['ionic', 'ngStorage',
     'zongotechWpApp.controllers','ngCordova','ezfb']);
    
    app.run(function ( $rootScope, $http,$ionicPlatform) 
    {        
        $ionicPlatform.ready(function () {
            // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
            // for form inputs)
            if (cordova.platformId === 'ios' && window.cordova && window.cordova.plugins.Keyboard) {
                cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
                cordova.plugins.Keyboard.disableScroll(true);

            }
            if (window.StatusBar) {
                // org.apache.cordova.statusbar required
                StatusBar.styleDefault();
            }

            //admob
            var admobid = {};
            // select the right Ad Id according to platform
            if (/(android)/i.test(navigator.userAgent)) {
                admobid = { // for Android
                    banner: 'ca-app-pub-3719812641536700/5049909072',//ca-app-pub-9577040959472230/3851211304',//,
                    interstitial: 'ca-app-pub-3719812641536700/6526642274'
                };
            } else if (/(ipod|iphone|ipad)/i.test(navigator.userAgent)) {
                admobid = { // for iOS
                    banner: 'ca-app-pub-3719812641536700/5049909072',
                    interstitial: 'ca-app-pub-3719812641536700/6526642274'
                };
            } else {
                admobid = { // for Windows Phone
                    banner: 'ca-app-pub-9577040959472230/3851211304',//ca-app-pub-3719812641536700/5049909072',
                    interstitial: 'ca-app-pub-3719812641536700/6526642274'
                };
            }

            if (window.AdMob) AdMob.createBanner({
                adId: admobid.banner,
                isTesting: false,//comment this out before publishing the app
                position: AdMob.AD_POSITION.BOTTOM_CENTER,
                autoShow: true
            });

            if (window.AdMob) AdMob.prepareInterstitial({
                adId: admobid.interstitial,
                isTesting:false, //comment this out before publishing the app
                autoShow: false
            });

            //end admob


//start onesignale PUSH NOTIFICATION
  var notificationOpenedCallback = function(jsonData) {
    console.log('didReceiveRemoteNotificationCallBack: ' + JSON.stringify(jsonData));
  };

  window.plugins.OneSignal.init("d422b292-eb37-4613-8b27-dd1d3dffdc0a",//app id
                                 {googleProjectNumber: "844439757829"},//google project number
                                 notificationOpenedCallback);
  
  // Show an alert box if a notification comes in when the user is in your app.
  window.plugins.OneSignal.enableInAppAlertNotification(true);
//END PUSH NOTIFICATION

//start twiiter
// if (TwitterService.isAuthenticated()) {
//             $scope.showHomeTimeline();
//         } else {
//             TwitterService.initialize().then(function(result) {
//                 if(result === true) {
//                     $scope.showHomeTimeline();
//                 }
//             });
//         }
        //end twitter



                    });


    });

    

    app.config(function (ezfbProvider,$stateProvider, $urlRouterProvider) {
ezfbProvider.setLocale('en_US');
  ezfbProvider.setInitParams({
    // This is my FB app id for plunker demo appb24
    appId: '165266376870364', 

    // Module default is `v2.6`.
    // If you want to use Facebook platform `v2.3`, you'll have to add the following parameter.
    // https://developers.facebook.com/docs/javascript/reference/FB.init
    version: 'v2.3'
  });
        $stateProvider
          .state('search', {
              url: '/search',
              templateUrl: 'templates/search.html'
          })
          
          .state('tabs', {
              url: "/tab",
              abstract: true,
              templateUrl: "templates/tabs.html"
          })
          .state('tabs.home', {
              url: "/home",
              views: {
                  'home-tab': {
                      templateUrl: "templates/home.html",
                      controller: 'HomeTabCtrl'
                  }
              }
          })

              .state('tabs.post', {
                  url: "/postDetail/:postId",
                  views: {
                      'home-tab': {
                          templateUrl: "templates/postDetail.html",
                          controller: 'PostCtrl'
                      }
                  }
              })

                          

             .state('tabs.contentByCategory', {
                 url: '/contentByCategory/:catId',
                 views: {
                     'more-tab': {
                         templateUrl: "templates/contentByCategory.html",
                         controller: 'CatCtrl'
                     }
                 }
             })
            .state('tabs.favorites', {
                url: "/favorites",
                views: {
                    'favorites-tab': {
                        templateUrl: "templates/favorites.html",
                        controller: 'FavCtrl'

                    }
                }
            })
          
          .state('tabs.more', {
              url: "/sections",
              views: {
                  'more-tab': {
                      templateUrl: "templates/sections.html",
                      controller: 'CatListCtrl'
                  }
              }
          })
          
         
            .state('tabs.about', {
                url: "/about",
                views: {
                    'more-tab': {
                        templateUrl: "templates/about.html"
                    }
                }
            })
            .state('tabs.facebook', {
                url: "/facebook",
                views: {
                    'facebook-tab': {
                        templateUrl: "templates/facebook.html",
                        controller: 'MyFacebookCtrl'

                    }
                }
            })


.state('tabs.twitter', {
                url: "/mytwitter",
                views: {
                    'twitter-tab': {
                        templateUrl: "templates/myTwitter.html",
                        controller: 'MyTwitterCtrl'

                    }
                }
            })

          .state('tabs.contact', {
              url: "/contact",
              views: {
                  'more-tab': {
                      templateUrl: "templates/contact.html"
                  }
              }
          });


        $urlRouterProvider.otherwise("/tab/home");

    });

    //replace with your API. Please do not forget / at the END

     app.constant('wpzSettings', {
    siteApiUrl:  'http://davidzongo.com/api/',//"http://lesaffairesbf.com/b24api/",//
    homeTitle:'WpZ news',
     featureTitle:'Breaking',
    featureCategory: 9,//13,//32; 2058,
        widget_data_username: "zongotech",
        widget_data_count: 5
});
   
   app.factory('TwitterService', function($cordovaOauth, $cordovaOauthUtility, $http, $resource, $q) {
    // 1
    var twitterKey = "STORAGE.TWITTER.KEY";
    var clientId = '4PNasflvjz2SdNidryqVAPjhI';//TwitterAppConsumerKey';
    var clientSecret = 'DG4yMYx8RtjC6Kn7tXWWsbijMPfUQz31ouiYBeSvBYpdNU83Co';//TwitterAppConsumerSecret';

    // 2
    function storeUserToken(data) {
        window.localStorage.setItem(twitterKey, JSON.stringify(data));
    }

    function getStoredToken() {
        return window.localStorage.getItem(twitterKey);
    }

    // 3
    function createTwitterSignature(method, url) {
        var token = angular.fromJson(getStoredToken());
        var oauthObject = {
            oauth_consumer_key: clientId,
            oauth_nonce: $cordovaOauthUtility.createNonce(10),
            oauth_signature_method: "HMAC-SHA1",
            oauth_token: token.oauth_token,
            oauth_timestamp: Math.round((new Date()).getTime() / 1000.0),
            oauth_version: "1.0"
        };
        var signatureObj = $cordovaOauthUtility.createSignature(method, url, oauthObject, {}, clientSecret, token.oauth_token_secret);
        $http.defaults.headers.common.Authorization = signatureObj.authorization_header;
    }

    return {
        // 4
        initialize: function() {
            var deferred = $q.defer();
            var token = getStoredToken();

            if (token !== null) {
                deferred.resolve(true);
            } else {
                $cordovaOauth.twitter(clientId, clientSecret).then(function(result) {
                    storeUserToken(result);
                    deferred.resolve(true);
                }, function(error) {
                    deferred.reject(false);
                });
            }
            return deferred.promise;
        },
        // 5
        isAuthenticated: function() {
            return getStoredToken() !== null;
        },
        // 6
        getHomeTimeline: function() {
            var home_tl_url = 'https://api.twitter.com/1.1/statuses/home_timeline.json';
            createTwitterSignature('GET', home_tl_url);
            return $resource(home_tl_url).query();
        },
        storeUserToken: storeUserToken,
        getStoredToken: getStoredToken,
        createTwitterSignature: createTwitterSignature
    };
});
}());